Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: yogesh@makitweb.com
Tutorial Link: https://makitweb.com/how-to-delete-record-from-mysql-table-with-ajax/

Instructions -

## Import attached posts.sql file in your MySQL database.
## Update config.php file.
